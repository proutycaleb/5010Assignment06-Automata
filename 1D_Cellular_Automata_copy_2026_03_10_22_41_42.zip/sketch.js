let w = 8;
let colums, rows;
let board;


function setup() {
  createCanvas(640, 640);
  columns = width / w;
  rows = height / w;
  board = create2DArray(columns, rows);
  frameRate(15);
  for (let i = 1; i < columns - 1; i++) {
    for (let j = 1; j < rows - 1; j++) {
      board[i][j] = floor(random(2));
    }
  }
}

function draw() {
  let next = create2DArray(columns, rows);
  
  for (let i = 1; i < columns - 1; i++) {
    for (let j = 1; j < rows - 1; j++) {
    
      let neighborSum = 0;
      for (let k = -1; k <= 1; k++) {
        for (let l = -1; l <= 1; l++){
          neighborSum += board[i + k][j + l]
        }
      }
      neighborSum -= board[i][j];
    
      let rand = random(1, 100)
      if (board[i][j] === 1 && neighborSum < 2 && rand <= 20) next[i][j] = 0;
      else if (board[i][j] === 1 && neighborSum > 3 && rand <= 20) next[i][j] = 0;
      else if (board[i][j] === 0 && neighborSum === 3) next[i][j] = 1;
      else next[i][j] = board[i][j];
    }
  }


  for (let i = 0; i < columns; i++) {
    for (let j = 0; j < rows; j++) {
      fill (255 - board [i][j] * 255);
      stroke(0);
      square(i * w, j * w, w);
    }
  }
  board = next;
}


function create2DArray(columns, rows) {
  let arr = new Array(columns);
  for (let i = 0; i < columns; i++){
    arr[i] = new Array(rows);
    for (let j = 0; j < rows; j++) {
      arr[i][j] = 0;
    }
  }
  return arr;
}
